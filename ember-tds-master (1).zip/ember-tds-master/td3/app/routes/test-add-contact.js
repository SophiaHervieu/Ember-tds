import Route from '@ember/routing/route';

export default Route.extend({
  model(){
    let contacts = this.get('store').findAll('contact');
  },
  actions:{
    addNew:function(){
      let store=this.get('store');
      let contact=store.createRecord({
        nom:'SMITH',
        prenom:'Jhon',
        email:'j.smith@machin.com'
      });
      contact.save();
    }
  }
});

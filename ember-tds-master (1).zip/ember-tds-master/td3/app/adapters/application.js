import LSAdapter from 'ember-localstorage-adapter';

export default LSAdapter.extend({
  namespace:'contact-app'
});

import {LSSerializer} from 'ember-localstorage-adapter';

export default LSSerializer.extend({
});
